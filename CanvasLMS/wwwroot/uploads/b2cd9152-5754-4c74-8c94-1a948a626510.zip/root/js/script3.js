/*
    DOM -> document.querySelector() - Objetos
        -> document.querySelectorAll() - NodeList
    Simular BackEnd - CRUD
*/
"use strict"  /*ESCRIBIR JS DE FORMA CORRRECTA*/
/*
const lstP =  document.querySelectorAll(".caja p.recuadro");
lstP.forEach( parrafo => {
    parrafo.style.backgroundColor ="green";
});

const body = document.querySelector("body");
      body.style.backgroundColor = "#A8C3BC";
*/

/* 1. ARRAY - BACKEND */
var personas = [
    {
      nombre: "Juan",
      apellido: "Pérez",
      direccion: "Calle 123, Ciudad X",
      correo: "juan.perez@email.com"
    },
    {
      nombre: "María",
      apellido: "Gómez",
      direccion: "Avenida ABC, Ciudad Y",
      correo: "maria.gomez@email.com"
    },
    {
      nombre: "Carlos",
      apellido: "Martínez",
      direccion: "Carrera XYZ, Ciudad Z",
      correo: "carlos.martinez@email.com"
    },
    {
      nombre: "Luis",
      apellido: "Rodríguez",
      direccion: "Paseo 456, Ciudad A",
      correo: "luis.rodriguez@email.com"
    },
    {
      nombre: "Ana",
      apellido: "López",
      direccion: "Plaza 789, Ciudad B",
      correo: "ana.lopez@email.com"
    },
    {
      nombre: "Pedro",
      apellido: "García",
      direccion: "Ruta 101, Ciudad C",
      correo: "pedro.garcia@email.com"
    },
    {
      nombre: "Sofía",
      apellido: "Hernández",
      direccion: "Bulevar 999, Ciudad D",
      correo: "sofia.hernandez@email.com"
    },
    {
      nombre: "Diego",
      apellido: "Díaz",
      direccion: "Autopista 777, Ciudad E",
      correo: "diego.diaz@email.com"
    },
    {
      nombre: "Elena",
      apellido: "Sánchez",
      direccion: "Camino 333, Ciudad F",
      correo: "elena.sanchez@email.com"
    },
    {
      nombre: "Pablo",
      apellido: "Ramírez",
      direccion: "Circuito 555, Ciudad G",
      correo: "pablo.ramirez@email.com"
    }
  ];

/* 2. GENERAL */  
const tblPersonas = document.querySelector("#tblPersonas tbody");
const frm = document.querySelector("#frm");
var idSeleccionado = null;


/* 3.METODOS */
const cargarTabla = ()=>{
    let filas = "";

    personas.forEach((persona, indice)=>{
        filas += `
                    <tr>
                        <td>${ persona.nombre }</td>
                        <td>${ persona.apellido }</td>
                        <td>${ persona.direccion }</td>
                        <td>${ persona.correo }</td>
                        <td>
                            <button type="button" class="btn btn-warning" onclick="cargarPersona(${ indice })">Editar</button>
                            <button type="button" class="btn btn-outline-danger" onclick="borraPersona(${ indice })">Borrar</button>
                        </td>
                    </tr>
                `;
    });

    tblPersonas.innerHTML = filas;
}

cargarTabla();

frm.btnGuardar.addEventListener("click", ()=>{
    const personaNueva = {
                            nombre: frm.txtNombre.value,
                            apellido: frm.txtApellido.value,
                            direccion: frm.txtDireccion.value,
                            correo: frm.txtCorreo.value,
                        };

    if(idSeleccionado === null){
        personas.push(personaNueva); 
    }else{
        personas.splice(idSeleccionado,1,personaNueva);    
    }
    cargarTabla();
    limpiar();
});

function limpiar() {
    frm.reset(); 
    frm.btnGuardar.innerHTML = "Guardar";   
    idSeleccionado = null;
}

frm.btnLimpiar.addEventListener("click", limpiar);

function borraPersona(id) {
    if(confirm("Desea borra el registro?")){
        personas.splice(id,1);
        cargarTabla();
    }    
}

function cargarPersona(id) {
    const personaSeleccionada = personas.find((persona, indice) => indice === id);

    frm.txtNombre.value = personaSeleccionada.nombre;
    frm.txtApellido.value = personaSeleccionada.apellido;
    frm.txtDireccion.value = personaSeleccionada.direccion;
    frm.txtCorreo.value = personaSeleccionada.correo;
    frm.btnGuardar.innerHTML = "Modificar";
    idSeleccionado = id;
    
    console.log(personaSeleccionada);
}

