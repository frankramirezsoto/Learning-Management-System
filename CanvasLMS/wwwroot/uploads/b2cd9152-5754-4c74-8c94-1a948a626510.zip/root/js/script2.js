/*
    ARREGLOS
*/

/* 1. CREAR UN VARIABLE */
const miArreglo = ["Ana", 5, 11, true, [], {}];

const estudiantes = ["Luis", "Allan", "Marco", "Tomas", "Alison"];
const numeros = [55,13,78,61,26,34,10,3,61,8,13];

/* 2. RECORRER EL ARREGLO */

console.log(estudiantes);
console.log(estudiantes[estudiantes.length - 1]);

/*
for (let index = 0; index < estudiantes.length; index++) {
    console.log(estudiantes[index], index);
}

estudiantes.forEach(function(estudiante, indice){
    console.log(estudiante, indice);
});

estudiantes.forEach((estudiante, indice) => console.log(estudiante, indice));
*/


/* 3. AGREGAR PUSH() | ELIMINAR POP() */
/* estudiantes.push("Kevin", "Josue","Gael");
estudiantes.pop();estudiantes.pop();estudiantes.pop(); */

/* 
    array.splice(inicio, contEliminar, ...valor)
    inicio -> Indice donde quiero colocar.
    contEliminar -> 0:Inserta/Modifica >0: Elimina items
    ...valor -> Agregar al arreglo
*/
estudiantes.splice(2,0,"Kevin", "Josue","Gael");
/* estudiantes.splice(2,1);
estudiantes.splice(4,1, "Valeria"); */

estudiantes.forEach(estudiante => console.log(estudiante));

estudiantes.push("Josue")
/* 4.VER FUNCIONES -> CLONAN ARREGLO */
console.log(estudiantes);

console.log(estudiantes.concat(numeros));

console.log(estudiantes.filter( estudiante => estudiante.length > 4));

console.log(estudiantes.find(estudiante => estudiante === "Josue"));
console.log(estudiantes.findIndex(estudiante => estudiante === "Josue"));
console.log(estudiantes.findLast(estudiante => estudiante === "Josue"));
console.log(estudiantes.findLastIndex(estudiante => estudiante === "Josue"));

console.log(estudiantes.toString());
console.log(estudiantes.join(' '));
console.log(estudiantes.map((estudiante, indice) => `El estudiante en el indice ${indice} es ${estudiante}`).join(" ")); //*

document.getElementById("lista").innerHTML = estudiantes.map(estudiante => `<li>${estudiante}</li>`).join("");

console.log(estudiantes.sort());
console.log(estudiantes.reverse());

console.log(numeros.sort((a, b) => a - b).reverse());

/******************************/
/***** OBJETOS ******/
console.log("******************************");

/* 1.CREAR OBJETOS EN BASE A {} --> CODIGO : VALOR */
nombre = "Warner"
const estudiante1 = {
    nombre:"Belén",
    apellidos:"Camacho Sequeira",
    direccion:"San José",
    saludar:function(){
        return `Hola, soy ${this.nombre}`;
    },
    nombreCompleto: ()=> `${estudiante1.nombre} ${estudiante1.apellidos}`
};
console.log(estudiante1);
console.log(estudiante1.nombreCompleto());
//console.log(estudiante1["nombre"]);

/* 2.CREAR UN OBJETO EN BASE A UNA INSTACION DE OBJECT */
const estudiante2 = new Object();
      estudiante2.nombre = "Emiliano";
      estudiante2.apellidos = "Madrigal Céspedes";
      estudiante2.direccion = "San José";
      estudiante2.nombreCompleto = ()=> `${estudiante2.nombre} ${estudiante2.apellidos}`

console.log(estudiante2);
console.log(estudiante2.nombreCompleto());

/* 3.CREAR OBJETOS EN BASE A UNA FUNCION CONSTRUCTORA */
function Estudiante(_nombre, _apellidos, _direccion) {
    this.nombre = _nombre;
    this.apellidos = _apellidos;
    this.direccion = _direccion
}
Estudiante.prototype.nombreCompleto = function(){
    return `${this.nombre} ${this.apellidos}`;
}


const estudiante3 = new Estudiante("Valeria","Jimenez Solano", "San José");
console.log(estudiante3);
console.log(estudiante3.nombreCompleto());

/* 4.CREAR OBJETOS EN BASE CLASES -> POO */
class Alumno{
    constructor(_nombre, _apellidos, _direccion) {
        this.nombre = _nombre;
        this.apellidos = _apellidos;
        this.direccion = _direccion
    }

    nombreCompleto(){
        return `${this.nombre} ${this.apellidos}`;
    }
}

const estudiante4 = new Alumno("Randy","Rojas Román", "San José");
console.log(estudiante4);
console.log(estudiante4.nombreCompleto());

/******************************/
/***** DOM ******/
console.log("******************************");
/*
    docuement.getElementById -> Atributo Id --> OBJETO
    docuement.getElementsByTagName -> Nombre Etiqueta --> HTMLCollection
    docuement.getElementsByClassName -> Atributo Clas --> HTMLCollection
*/

const body = document.getElementsByTagName("body")[0];
//console.log(body);
body.style.backgroundColor = "#C7C8CC";
body.style.font = "Arial";
body.style.fontSize = "16px";

const titulo1 = document.getElementsByTagName("h1");
for (let index = 0; index < titulo1.length; index++) {
    titulo1[index].style.backgroundColor = "#1C1C1C";
    titulo1[index].style.color = "#C7C8CC";
    titulo1[index].style.padding = "5px";
}

console.log(titulo1[0].innerHTML);
titulo1[0].innerHTML ="<marquee>HOLA MUNDO</marquee>";
//titulo1[0].innerText ="Adios!";

const parrafos = document.getElementsByTagName("p");

parrafos[0].classList.add("marcado");
parrafos[1].classList.add("recuadro");
parrafos[2].classList.add("redondo");
parrafos[2].classList.add("recuadro");

document.getElementById("demo").innerHTML = parrafos[2].innerHTML
document.getElementById("demo").classList.add("recuadro");


