/*
    FUNDAMENTOS DE JS
    06/03/2024
*/

/*
    1. VARIABLES
        VAR -> VARIABLE DE AMBITO SCRIPT - "GLOBALES"
        LET -> VARAIBLE DE AMBITO DEFINIDO - FUNCION
        CONST -> VARIABLE QUE NO CAMBIA SU VALOR
*/

var miSaludo = "Hola Mundo!";
var miNumero = 35;
var miEstado = true;
var miVariable;
var miObjeto = {};
var miArreglo = [];
var miFuncion = function(){};
var otraVariable = null;


console.log(typeof miSaludo);
console.log(typeof miNumero);
console.log(typeof miEstado);
console.log(typeof miVariable);
console.log(typeof miObjeto);
console.log(typeof miArreglo);
console.log(typeof miFuncion);
console.log(typeof otraVariable);

console.log("---------------------------------------");
/* 2.OPERADORES  */
var num1 = 10;
var num2 = 3;

console.log(num1 + num2);
console.log(num1 - num2);
console.log(num1 * num2);
console.log(num1 / num2);
console.log(num1 % num2);

console.log("---------------------------------------");
/* TEMPLATE STRING E INTERPOLACION */
console.log(num1 + " + " +num2 + " = " + (num1+num2));
console.log(`${num1} + ${num2} = ${(num1+num2)}`);

console.log("---------------------------------------");
/* 3. OPERADORES COMPARACION 
    A == B -> VALIDA VALORES | A === B -> VALIDA VALOR Y TIPO
    A > B | A < B | A <= B | A >= B
*/
var num3 = 10;
var num4 = "10";
console.log(num3 == num4); // TRUE 
console.log(num3 === num4); //  FALSE

console.log("---------------------------------------");
/* 4. SENTENCIAS IF | IF/ELSE | SWITCH */

var respuesta = "";

if (num3 == num4) {
    respuesta = true;    
} else {
    respuesta = false;
}

var diaSemana = 12;

switch (true) {
    case (diaSemana >= 1 && diaSemana <=5):
        respuesta = "Estre Semana";
        break;
    
    case (diaSemana >= 6 && diaSemana <=7):
        respuesta = "Fin Semana";
        break;

    default:
        respuesta = "N/A";
        break;
}
console.log(respuesta);

console.log("---------------------------------------");
/* 5. CICLOS: *FOR WHILE DO/WHILE */

for (let index = 0; index < 3; index++) {
    console.log(`For: Index = ${index}`);
}

var indexW = 0;
while (indexW < 3) {
    console.log(`While: IndexW = ${indexW}`);   
    indexW++; 
}

var indexD = 0;
do {
    console.log(`DoWhile: IndexD = ${indexD}`);   
    indexD++;     
} while (indexD < 3); 

/*
    1. MULTIPLICACION DE 2 VALORES SIN USAR *.
    2. RECORER LOS NUMEROS QUE HAY ENTRE N Y M, ME CUALES SON PARES, N DEBE SER MENOR QUE M
    3. DECLARAR 2 VARIABLES, X e Y, Y LE ASIGANA VALORES. LUEGO, MUESRTA POR CONSOLA
       LA SUMA, RESTA, MULTIPLICCION, DIVISION y MODULO DE x e y.
*/

console.log("---------------------------------------");
/* 5. FUNCIONES 
    FUNCIONES TRADICIONALES & ANONIMAS
    PARAMETROS Y RECIBEN ARGUMENTOS
    CAPACIDAD DE DEVOLVER O NO ALGO AL ENTORNO
*/

function multiplicar(param1, param2 = 10) {
    let respuesta = 0;

    for (let index = 0; index < param1; index++) {
        respuesta += param2
    }

    return respuesta;
}

const resta = function (param1, param2) {
    return param1 - param2   
}

console.log(multiplicar(5, 5));

/* FUNCIONES CALLBACK --> SON FUNCIONES QUE TRABAJAN COMO ARGUMENTO DE UN PARAMETRO DE OTROA FUNCION */

function saludar(persona) {
    console.log(`Hola ${persona}`);    
}

saludar("Ana");
saludar("Pedro");

function procesarSaludo(callBack) {
    let nombre = "María";
    callBack(nombre);   
}
procesarSaludo(saludar);

/* FUNCIONES FLECHA | ARROW */

/*
const sumar = function(p1,p2) {
    return p1 +p2;
}


const sumar = (p1,p2) => {
    return p1 +p2;
}
*/

const sumar = (p1,p2) => p1 + p2; 

console.log(sumar(15,33));











